var auto = (function(auto, $) {

  var create = function(target, o) {

    var modal = $("<div>");

    modal.addClass("automodal");

    modal.html("<div class='box'><div class='wrapper'><div class='header'><span></span><b class='close'>x</b></div><div class='content'></div><div></div>");

    $("body").append(modal);

    var hide = function() {
      modal.hide();
    };

    modal.on("click", hide);
    modal.find(".content").append(target || '');
    modal.find(".close").on("click", hide);
    modal.find(".box").on("click", function(e) {
      var event = window.event || e;

      if (event.stopPropagation)
        event.stopPropagation();
      else
        event.cancelBubble = true;

      return false;
    });

    $(target).show();

    return modal;
  };

  $.fn.automodal = function(o) {
    return this.each(function() {
      if (o === 'hide') {
        if (this.modal)
          this.modal.hide();
      } else {
        this.modal = this.modal || create(this, o);

        this.modal.find(".header span").text(o.title || 'D');
        this.modal.show().find(".wrapper").center();
      }
    });
  };

}(auto || {}, jQuery));
