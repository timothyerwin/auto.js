var auto = (function(auto, $) {

  var hideAll = function() {
    $(".popover:visible").hide();
  };

  $("body").on('click touchstart', function() {
    hideAll();
  });

  var cancelEvent = function(e) {
    var event = window.event || e;

    if (event.stopPropagation)
      event.stopPropagation();
    else
      event.cancelBubble = true;
  };

  $.fn.autopopover = function(o) {
    return this.each(function() {

      var activator = $(this);
      var popover = $(o.popover);

      o.position = o.position || "bottom center";

      var positions = o.position.split(" ");

      if(positions.length == 1)
        positions.push("center");

      var ppos = positions[0];
      var apos = positions[1];

      var positionLookup = {
        "bottom":{
          my: "left top",
          at: "left bottom+15px",
          arrow: "top"
        },
        "top":{
          my: "left bottom",
          at: "left top-15px",
          arrow: "bottom"
        },
        "left":{
          my: "right top",
          at: "left-15px top-15px",
          arrow: "right"
        },
        "right":{
          my: "left top",
          at: "right+15px top-15px",
          arrow: "left"
        }
      };

      var pos = positionLookup[ppos];

      popover.addClass("arrow-" + pos.arrow);

      popover.position({
          my: pos.my,
          at: pos.at,
          of: activator,
          collision: "none"
      });

      popover.on('click touchstart', cancelEvent);

      activator.on('touchstart', cancelEvent);
      activator.on('click', function(e) {

        cancelEvent(e);

        hideAll();

        popover.toggle();
      });
    });
  };

}(auto, jQuery));
