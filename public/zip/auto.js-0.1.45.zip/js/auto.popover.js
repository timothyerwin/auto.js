var auto = (function(auto, $) {

  var hideAll = function() {
    $(".popover:visible").hide();
  };

  $("body").on('click touchstart', function() {
    hideAll();
  });

  var cancelEvent = function(e) {
    var event = window.event || e;

    if (event.stopPropagation)
      event.stopPropagation();
    else
      event.cancelBubble = true;
  };

  $.fn.autopopover = function(o) {
    return this.each(function() {

      var activator = $(this);
      var popover = $(o.popover);

      o.position = o.position || "top";

      popover.addClass("arrow-" + o.position);

      popover.position({
          my: "left top",
          at: "left bottom+15px",
          of: activator
      });

      popover.on('click touchstart', cancelEvent);

      activator.on('touchstart', cancelEvent);
      activator.on('click', function(e) {

        cancelEvent(e);

        hideAll();

        popover.toggle();
      });
    });
  };

}(auto, jQuery));
